# OpenSignals-Travel-Helper-CP

## Contenpack for the Opensignalsmod from MrTroble, Uhutown and Jeronimo.

**This content pack adds new Signals to Opensignals.**
The pack contains:

-  Travelhelper Signals
-  Zp9 Signals
-  Zp9 Control Column
-  Brake Test Signals


Download: 
[Github](https://github.com/Skywalkervalle/OpenSignals-Travel-Helper-CP/raw/refs/heads/main/OpenSignals-Travel-Helper-CP.zip)

Pictures:

<img width="3840" height="2126" alt="2025-11-22_00 43 58" src="https://github.com/user-attachments/assets/741af019-f007-47a5-8e6d-e20c087b6d7d" />
<img width="3840" height="2126" alt="2025-11-21_23 40 49" src="https://github.com/user-attachments/assets/4e45f515-7128-46f1-8def-6d8867c7a12d" />
<img width="3840" height="2126" alt="2025-11-21_23 39 42" src="https://github.com/user-attachments/assets/b9520aa2-0c3b-4e3b-92b2-ca79c6a9f8f2" />
<img width="3840" height="2126" alt="2025-11-22_00 49 54" src="https://github.com/user-attachments/assets/210f0f22-a1d1-4db2-8769-0421437dbce6" />
<img width="3840" height="2126" alt="2025-11-22_00 50 03" src="https://github.com/user-attachments/assets/4d6e4c3f-4134-4ddd-9aec-aa258402e0b6" />
<img width="3840" height="2126" alt="2025-11-22_00 50 16" src="https://github.com/user-attachments/assets/a359a019-273a-4ad5-9fad-b5009fd63708" />
<img width="3840" height="2126" alt="2025-11-22_00 50 27" src="https://github.com/user-attachments/assets/a2c731d6-cd3d-4080-ad9d-798178fdcc70" />

